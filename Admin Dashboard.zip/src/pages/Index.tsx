
import HomeScreen from "@/components/Home/HomeScreen";

const Index = () => {
  return <HomeScreen />;
};

export default Index;
