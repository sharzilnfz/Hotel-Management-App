import React from "react";
import MenuCategoriesContent from "@/components/Admin/Restaurant/MenuCategoriesContent";

const MenuCategoriesPage: React.FC = () => {
  return <MenuCategoriesContent />;
};

export default MenuCategoriesPage; 