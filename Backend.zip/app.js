import meetingHallRoutes from './routes/meeting-hall/meeting-hall.routes.js';

// API routes
// ... existing route setups
app.use('/api/meeting-hall', meetingHallRoutes);

// ... existing error handling 